package com.hakiki95.androidcrudvolley.Util;

/**
 * Created by hakiki95 on 11/30/2016.
 */

public class ServerAPI {
    public static final String URL_DATA = "http://10.0.3.2/crud_android/view_data.php";
    public static final String URL_INSERT = "http://10.0.3.2/crud_android/create_data.php";
    public static final String URL_DELETE = "http://10.0.3.2/crud_android/delete_data.php";
    public static final String URL_UPDATE = "http://10.0.3.2/crud_android/update_data.php";
}
